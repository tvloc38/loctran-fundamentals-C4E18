from turtle import *

speed(-1)
color("green")
fillcolor("yellow")

begin_fill()

# hinhvuong
# for i in range(4):
#     forward(100)
#     left(90)

# tamgiac
# for i in range(3):
#     forward(100)
#     left(120)

end_fill()

# hinhtron
for i in range(36):
    circle(50)
    left(10)
    


mainloop()