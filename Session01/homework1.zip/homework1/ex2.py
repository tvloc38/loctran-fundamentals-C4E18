#Ex02
# radius = int(input("Radius?"))
# area = radius**2 * 3.14
# print(area)

#Ex03
# c = int(input("Enter the temperature in Celsius?"))
# f = (c * 1.8) + 32
# print(c,"(C)" "=",f,"(F)")